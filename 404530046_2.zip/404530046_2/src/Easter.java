public class Easter {

	public static void main(String[] args) {
		// TODO �۰ʲ��ͪ���k Stub
    
		System.out.println(EasterTester.getEasterDate(2001));
		System.out.println(EasterTester.getEasterDate(2012));
		
		}

}