public class EasterTester {

	public static void main(String[] args) {
		// TODO �۰ʲ��ͪ���k Stub
    
		System.out.println(Easter.getEasterDate(2001));
		System.out.println(Easter.getEasterDate(2012));
		
		}

}